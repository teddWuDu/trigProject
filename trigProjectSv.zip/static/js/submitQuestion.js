
const submit0 =  async function(event){
// id choice type section
    event.preventDefault();
    const id = document.querySelector("#id0").value;
    const choice = document.querySelector("#choice0").value;
    const type = document.querySelector("#type0").value;
    const section = document.querySelector("#section0").value;

   const prom =  fetch("/auth/question",{
       method: "POST",
    headers: {

        'Content-Type': "application/json"
        
    },
       body: JSON.stringify({
        id,
           choice,
           type,
           section,
           
       })

       
   });
    const layer1 = await prom;
    const reply = await layer1.text();
    document.querySelector("#display").innerHTML = reply;   

document.querySelectorAll(".submit").forEach((Element)=>{

            Element.setAttribute("disabled","true");
        })


}


const submit1 =  async function(event){
// id choice type section
    event.preventDefault();
    const id = document.querySelector("#id1").value;
    const choice = document.querySelector("#choice1").value;
    const type = document.querySelector("#type1").value;
    const section = document.querySelector("#section1").value;

   const prom =  fetch("/auth/question",{
       method: "POST",
    headers: {

        'Content-Type': "application/json"

    },
       body: JSON.stringify({
        id,
           choice,
           type,
           section,

       })


   });
    const layer1 = await prom;
    const reply = await layer1.text();
    document.querySelector("#display").innerHTML = reply;

document.querySelectorAll(".submit").forEach((Element)=>{

            Element.setAttribute("disabled","true");
        })


}



const submit2 =  async function(event){
// id choice type section
    event.preventDefault();
    const id = document.querySelector("#id2").value;
    const choice = document.querySelector("#choice2").value;
    const type = document.querySelector("#type2").value;
    const section = document.querySelector("#section2").value;

   const prom =  fetch("/auth/question",{
       method: "POST",
    headers: {

        'Content-Type': "application/json"

    },
       body: JSON.stringify({
        id,
           choice,
           type,
           section,

       })


   });
    const layer1 = await prom;
    const reply = await layer1.text();
    document.querySelector("#display").innerHTML = reply;

document.querySelectorAll(".submit").forEach((Element)=>{

            Element.setAttribute("disabled","true");
        })


}


const submit3 =  async function(event){
// id choice type section
    event.preventDefault();
    const id = document.querySelector("#id3").value;
    const choice = document.querySelector("#choice3").value;
    const type = document.querySelector("#type3").value;
    const section = document.querySelector("#section3").value;

   const prom =  fetch("/auth/question",{
       method: "POST",
    headers: {

        'Content-Type': "application/json"

    },
       body: JSON.stringify({
        id,
           choice,
           type,
           section,

       })


   });
    const layer1 = await prom;
    const reply = await layer1.text();
    document.querySelector("#display").innerHTML = reply;

document.querySelectorAll(".submit").forEach((Element)=>{

            Element.setAttribute("disabled","true");
        })


}

