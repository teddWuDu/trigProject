
const getQuestion = async function(questionType,section){

if(questionType!=="multipleChoice" && questionType!=="freeResponse"){

	alert("BAD REQUEST");

}else if(section!=="trigDefinition" && section!=="trigFormulas" && section!=="trigTransformation" && section!=="complexTrig"){
	
	alert("BAD REQUEST");

}


const response = fetch("/auth/getQuestion",{
    headers: {
    'Content-Type': "application/json"
        
    },
    method: "POST",
    body: JSON.stringify({
        type: questionType,
    section: section        
    })
    
    
})

	response.catch((err)=>{

		alert("A FATAL ERROR HAS OCCURED");

	})

	const layer1 = await response;
	const text = await layer1.text();
	return text

}
