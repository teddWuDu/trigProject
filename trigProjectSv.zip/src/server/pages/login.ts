
import {Request,Response} from "express";

export const handler = function(req: Request, res: Response){


res.render("./login",{

	username: (req?.session as any).username,
	password: (req?.session as any).password


})


//NO LOGIN PAGE YET..


}
