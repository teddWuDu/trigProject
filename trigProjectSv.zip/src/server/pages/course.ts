
import {Request,Response} from "express";
import pages from "../database/pages";

export const handler = async function(req: Request, res: Response){

	if(typeof(req.params.course==="string") && req?.query?.page){

		const result = await pages.savePage((req as any).session.username,(req as any).params.course,Number(req.query.page));
		res.render((req as any).params.course+req.query.page);
	
	}else{
		
	res.end("INVAID URL");


	
	}

}
