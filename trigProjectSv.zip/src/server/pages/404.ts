
import {Request,Response} from "express";

export const handler = function(req: Request, res: Response){



        res.end("<h1>NOT FOUND!</h1>")



}
