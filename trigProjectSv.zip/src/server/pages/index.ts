import table from "./table";

export default async function(app: any){

for(let element of table){

	let {handler} = await import(element[1])
app.get(element[0],handler);


}



}
