
import {Request,Response} from "express";
import friends from "../database/friends";

export const handler = async function(req: Request, res: Response){
	if(typeof(req.query.username)!=="string"){
	res.end("NO USERNAME SPECIFIED");
	return
	}
	const success = await friends.addFriend((req as any).session.username,req.query.username);
	if(success===false){
	
	res.end("FRIEND ALREADY ADDED");
	return
	}
	
	res.end("friend SUCCESS added");
	
	

}
