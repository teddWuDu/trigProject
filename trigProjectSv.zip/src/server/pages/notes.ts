
import {Request,Response} from "express";
import notes from "../database/notes";

export const handler = async function(req: Request, res: Response){

	if((req as any).session.username){
res.render("notes",{

notes: await notes.getPersonalNotes((req as any).session.username),

})
	}else{
	
		res.end("<h1> NO USERNAME</h1>")
	
	}
}
