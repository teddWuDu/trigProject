
import {Request,Response} from "express";

export const handler = function(req: Request, res: Response){

res.render("pin")


}
