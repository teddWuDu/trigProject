
import {Request,Response} from "express";
import Progress from "../database/progress";
import Pages from "../database/pages";

export const handler = async function(req: Request, res: Response){

const  progress = await Progress.getProgressInfo((req as any).session.username);

const trigDefinitionPage = await Pages.getPage((req as any).session.username,'trigDefinition') ?? 0;
const trigFormulasPage = await Pages.getPage((req as any).session.username,'trigFormulas') ?? 0;
const trigTransformationPage = await Pages.getPage((req as any).session.username,'trigTransformation') ?? 0;
const complexTrigPage = await Pages.getPage((req as any).session.username,'complexTrig') ?? 0;



console.log(progress);
console.log(trigDefinitionPage);
	if((req as any)?.session.username){
console.log(progress);
res.render("homepage",{

	username: (req?.session as any)?.username,
	...progress[0],
	trigDefinitionPage,
	trigFormulasPage,
	trigTransformationPage,
	complexTrigPage,
})

	}else{
	
	res.end("NO USERNAME");
	
	}
}
