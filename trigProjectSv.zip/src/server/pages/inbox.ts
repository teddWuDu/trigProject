
import {Request,Response} from "express";
import inbox from "../database/inbox";

export const handler = async function(req: Request, res: Response){

	const data = await inbox.getMessages((req as any).session.username);

	res.render("inbox",{
	
		data
	
	})



}
