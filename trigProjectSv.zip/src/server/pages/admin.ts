
import {Request,Response} from "express";


export const handler =  function(req: Request, res: Response){

	if(req.query.type=="freeResponse"){
	
	res.render("adminFreeResponse");	
	
	}else if(req.query.type=="multipleChoice"){
	
	res.render("adminMultipleChoice");	
	
	}else{
	
	res.redirect("/auth/admin?type=multipleChoice");
	
	}

}
