
import {Request,Response} from "express";

export const handler = function(req: Request, res: Response){

	res.render("quizMe",{
	
		section: req.query.section
	
	})


}
