
import {Request,Response} from "express";



export const handler = async function(req: Request, res: Response){


res.render("./signup")


}
