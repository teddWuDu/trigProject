
import {Request,Response} from "express";

export const handler = function(req: Request, res: Response){

	req.session.destroy((err: any)=>{});
	  res.render("logout");


}
