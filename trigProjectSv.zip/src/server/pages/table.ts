
const table =  [
	//First Url, then filename
	["/auth/chatbot","./chatbot.js"],
	["/login","./login.js"],
	["/signup","./signup.js"],
	["/pin","./pin.js"],
	["/auth/homepage","./homepage.js"],
	["/auth/logout","./logout.js"],
	["/auth/notes","./notes.js"],
	["/","./signup.js"],	
	["/auth/searchNote","./searchNote.js"],
	["/auth/courses/:course","./course.js"],
	["/auth/quizMe","./quizMe.js"],
	["/auth/admin","./admin.js"],
	["/auth/social","./social.js"],
	["/auth/createChat","./createChat.js"],
	["/auth/chat","./chat.js"],
	["/auth/findChat","./findChat.js"],
	["/auth/profile","./profile.js"],
	["/auth/searchProfile","./searchProfile.js"],
	["/auth/inbox","./inbox.js"],
	["/auth/friend","./friend.js"],
	["/auth/friends","./friends.js"],
	["/auth/questions","./seeQuestions.js"]
]


export default table;
