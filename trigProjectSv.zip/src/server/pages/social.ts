
import {Request,Response} from "express";
import profiles from "../database/profile";
import history from "../database/history";

export const handler = async function(req: Request, res: Response){

	const data = await profiles.getProfile((req as any).session.username);
	const data1 = await history.getHistory((req as any).session.username);
	if(!data){
		res.end("<h1> FATAL SERVER ERROR </h1>")
		return
	
	}

	res.render("social",{
		data: data[0],
		history: data1
	})

}
