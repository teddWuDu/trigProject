
import {Request,Response} from "express";
import chatroom from "../database/chatroom";
import messages from "../database/messages";
import history from "../database/history";

export const handler = async function(req: Request, res: Response){

	const check = await chatroom.getChatInfo(req?.query?.pin?.toString());
if(check && req?.query?.pin){
const del: boolean = check[0].creator==(req as any).session.username
res.render("chat",{
	del,
	data: check

});
history.addToHistory((req as any).session.username,req?.query?.pin?.toString());


}else{

	res.end("<h2> NO CHAT FOUND </h2>");

}



}
