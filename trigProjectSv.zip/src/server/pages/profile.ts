
import {Request,Response} from "express";
import profile from "../database/profile";

export const handler = async function(req: Request, res: Response){

	if(typeof(req.query.username)=="string"){
	const data = await profile.getProfile(req.query.username);
	console.log(data);
	if(data){
	
	res.render("profile",{
		
		data: data[0]
	})
	
	}else{
	
	
		res.end("<h1> USER NOT FOUND </h1>")
	
	}
	
	
	
	}else{
	
		res.end("<h1> NO USERNAME FOUND </h1>")
	
	}


}
