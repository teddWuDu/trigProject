
import {Request,Response} from "express";
import freeResponse from "../database/freeResponse";
import multipleChoice from "../database/multipleChoice";

export const handler  = async function(req: Request, res: Response){

const table1 = await freeResponse.getAll();
const table2 = await multipleChoice.getAll();

res.render("seeQuestions",{

	table1,
	table2

})
	


}
