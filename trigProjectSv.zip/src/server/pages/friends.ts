
import {Request,Response} from "express";
import friends from "../database/friends";

export const handler = async function(req: Request, res: Response){

	const data = await friends.getFriends((req as any).session.username);
	console.log(data);	
	res.render("friends",{
	
		data,
		username: (req as any).session.username
	
	})

}
