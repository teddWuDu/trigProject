import {Request,Response} from "express";
import {unlink} from "node:fs/promises";
import {resolve} from "node:path";
import notes from "../database/notes";

export const handler = function(req: Request, res: Response){

	if(typeof(req.params.filename)=="string"){
		if(req.body.changePerm=="change"){
		
		notes.changePermission((req as any).session.username,req.params.filename);
		res.redirect("/auth/notes");
		return
		}
		notes.deleteNote(req.params.filename);
		const path: any = resolve(__dirname,"../../../","static/files",req.params.filename);
		const promise = unlink(path)
		promise.catch((err)=>{
		
			res.end("<h1>COULD NOT DELETE FILE</h1>")
		
		})

		promise.then((data)=>{
		res.redirect("/auth/notes");
		})

	}else{
	
	res.end("you slow toogus, there is not file you dumb nut");
	
	}

}
