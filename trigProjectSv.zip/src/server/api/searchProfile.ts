
import {Request,Response} from "express";
import profiles from "../database/profile"; 

export const handler = async function(req: Request, res: Response){

	if(typeof(req.body.query)=="string"){
	const data = await profiles.searchProfile(req.body.query);

	if(data){
	
		res.render("profilesResult",{
		
			data
		
		})
	
	}else{
	
		res.end("<h1> NO RESULT FOUND </h1>")
	
	}

	
	
	}else{
	
	
		res.end("INVALID REQUEST");
	
	}



}
