
import {Request,Response} from "express";
import chatroom from "../database/chatroom";

export const handler = async function(req: Request, res: Response){

	if(typeof(req.body.query)!=="string"){
	res.end("NO SEARCH QUERY");
	return;
	}


const data = await chatroom.searchChats(req.body.query);

if(data){

	res.render("chatResults",{
		query: req.body.query,	
		data
	
	})

return
}
res.end("<h1> No Chat Found </h1>");

}
