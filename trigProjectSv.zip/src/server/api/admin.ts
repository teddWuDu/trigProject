
import {Request,Response} from "express";
import multipleChoice from "../database/multipleChoice";
import freeResponse from "../database/freeResponse";

export const handler = function(req: Request, res: Response){
if(!req.body.choice1){


	if(isNumber(req.body.solution)){
	
	if(req.body.catagory && req.body.description && req.body.question){
	
	req.body.solution = Number(req.body.solution);
	freeResponse.addQuestion(req.body);
	
	}
	
	
	}


res.render("adminFreeResponse")
return

}
	if(isNumber(req.body.solution)){
		if(Number(req.body.solution)<=4){
		if(req.body.catagory && req.body.question && req.body.choice1 && req.body.choice2 && req.body.choice3 && req.body.choice4){
	req.body.solution = Number(req.body.solution);
	multipleChoice.addQuestion(req.body);
res.render("adminMultipleChoice");
	return

	}
	
	}
	
	
	
	}


res.end("INVALID INPUT");

}



const isNumber = function(number: string): boolean{

        if(typeof(Number(number))=="number"){
                if(Number(number)==Number(number)){

                        return true

                }else{

                        return false
                }


        }else{

                return false

        }


}

