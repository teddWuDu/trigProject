
import {Request,Response} from "express";
import login from "../database/login";

export const handler = async function(req: Request, res: Response){
	let check: boolean = await login.checkUser(req.body.username,req.body.password);
	if(check){
                (req as any).session.username = req.body.username;
		(req as any).session.password = req.body.password;	
		res.redirect("/auth/homepage");
	
	}else{
	
		res.render("login",{
		
			error: true
		
		
		})
	
	}

}
