
import {Request,Response} from "express";
import messages from "../database/messages";

export const handler = async function(req: Request, res: Response){

	if(req.body.chatId){
const data = await messages.getMessages(req.body.chatId);
if(data){
	res.render("chatMessages",{
	
		data
	
	})

}else{


	res.end("NO HAT FOUND");

}

	}else{
	
		res.end("NO CHAT FOUND");
	
	}
}
