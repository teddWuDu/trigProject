
import {Request,Response} from "express";
import signup from "../database/signup";

export const handler = async function(req: Request, res: Response){

let success: (boolean | undefined) = await signup.addToUsers(req.body.pin);

if(success===false){

	res.render("pin",{
	
		error: true
	
	})

}else{

res.redirect("/auth/homepage");


}



}
