
import {Request,Response} from "express";
import chatbot from "../database/chatbot";


export const handler = async function(req: Request, res: Response){

const data = await chatbot.getMessages((req as any).session.username);

res.render("chatbotMessage",{

	data

})


}
