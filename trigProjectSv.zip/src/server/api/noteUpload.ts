
import {Request,Response} from "express";
import {writeFile} from "node:fs/promises";
import notes from "../database/notes";
import {resolve} from "node:path";

const currentDir = __dirname;


export const handler = async function(req: Request, res: Response){

	if(req?.file?.buffer){
	const pin = await notes.saveNote(req.file.originalname,(req as any).session.username,"true");


	if(typeof(pin)=="string"){
		
	writeFile(resolve(currentDir,"../../../static/files",pin),req.file.buffer);
	res.redirect("/auth/notes");	
	}else{
	
	res.end("FILE NOT SAVED CORRECTLY");
	
	}
	
	}else if(req.body.note && req.body.name){
        
	const pin = await notes.saveNote(req.body.name,(req as any).session.username,"true");	
	

        if(typeof(pin)=="string"){

        writeFile(resolve(currentDir,"../../../static/files",pin),req.body.note);
        res.redirect("/auth/notes");
        }
	
	
	}else{
	
	res.end("NO FILE");
	
	
	}


}
