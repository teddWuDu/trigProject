
import {Request,Response} from "express";
import multipleChoice from "../database/multipleChoice";
import freeResponse from "../database/freeResponse";

export const handler = async function(req: Request, res: Response){
	if(req.body.type=="multipleChoice"){

	const data = await multipleChoice.getRandomQuestion(req.body.section);
	
	if(!data){
	res.end("<h1> INTERNAL SERVER ERR</h1>");
	return
	
	}	

	let options = [];

	options.push(data.choice1);
	options.push(data.choice2);	
        options.push(data.choice3);
        options.push(data.choice4);

	res.render("multipleChoice",{
		...data,	
		options,
	})

	}else if(req.body.type=="freeResponse"){
	if(req.body.section){
	const data = await freeResponse.getRandomQuestion(req.body.section);
	if(data){
	
	res.render("freeResponse",{...data});
	
	}else{
	
		res.end("ENOSECTIONFOUND");
	
	}	
	
	
	}else{
	
	res.end("ENOSECTIONINBODY")
	
	}


	
	}else{
	
	res.end("<h1> INTERNAL SERVER ERROR OR HACKERS ENDING </h1>")
	
	}

}
