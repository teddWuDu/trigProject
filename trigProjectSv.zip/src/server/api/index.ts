import table from "./table";

export default async function(app: any){

for(let element of table){

	let {handler} = await import(element[1])
app[element[2]](element[0],handler);


}



}
