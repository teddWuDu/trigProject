
import {Request,Response} from "express";
import signup from "../database/signup.js";


export const handler = async function(req: Request,res:Response){

let success: boolean | undefined = await signup.addToPending(req.body.username,req.body.password,req.body.email);

if(success===false){

res.render("signup",{

	error: true

})

}else{

res.redirect("/pin");

}

}
