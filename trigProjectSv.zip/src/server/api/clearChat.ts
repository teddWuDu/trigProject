
import {Request,Response} from "express";
import chatbot from "../database/chatbot";

export const handler = function(req: Request, res: Response){

chatbot.deleteMessages((req as any).session.username);
res.end();
}
