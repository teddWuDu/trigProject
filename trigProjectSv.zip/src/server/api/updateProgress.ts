
import {Request,Response} from "express";
import progress from "../database/progress";
import multipleChoice from "../database/multipleChoice";
import freeResponse from "../database/freeResponse";

export const handler = async function(req: Request, res: Response){
		
if(req.body.type=="multipleChoice"){	
			const correct: boolean = await multipleChoice.verify(req.body.id,Number(req.body.choice));
			const description = await multipleChoice.getDescription(req.body.id);
		
			if(correct){
			
				progress.questionCorrect((req as any).session.username,req.body.section);

			
			}else{
			

                                progress.questionWrong((req as any).session.username,req.body.section);

			
			
			}
			res.render("describe",{
			
				correct,
				description,
							
			
			})
		
}else if(req.body.type=="freeResponse"){

	const correct = await freeResponse.verify(req.body.id,req.body.choice);
	const description = await freeResponse.getDescription(req.body.id);
		console.log(req.body.section);	
	
	if(correct){
	

                                progress.questionCorrect((req as any).session.username,req.body.section);
	
	
	}else{
	

                                progress.questionWrong((req as any).session.username,req.body.section);
	
	
	
	}
                 res.render("describe",{

                                correct,
                                description,


                        })



}else{


	res.end("ENOTANOPTION");

}
		



}
