
import {Request,Response} from "express";
import chatroom from "../database/chatroom";

export const handler = async function(req: Request, res: Response){
if(req.body.chatId){
const success = await chatroom.deleteChatroom(req.body.chatId,(req as any).session.username);

if(success==false){
res.end("NO CHATROOM FOUND")
return
}

res.end("DELETION SUCCESS");


}else{

	res.end("NO CHATROOM SPECIFIED");

}
}
