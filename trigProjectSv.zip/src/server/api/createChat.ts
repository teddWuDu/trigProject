

import {Request,Response} from "express";
import chatroom from "../database/chatroom";

export const handler = async function(req: Request, res: Response){

	if(req.body.name){
	const key = await chatroom.createChatroom((req as any).session.username, req.body.name);
	res.render("createChat",{

	pin: key	
	
	})
	}else{
	
		res.end("NO NAME MADE EFIELDLEFTBLANK");
	
	
	}


}
