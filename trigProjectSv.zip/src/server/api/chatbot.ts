
import {Request,Response} from "express";
import {spawn} from "child_process";
import chatbot from "../database/chatbot";
import {Writable} from "node:stream";

export const handler = async function(req: Request,res: Response){


await chatbot.addMessage((req as any).session.username,req.body.message);

let text: string | undefined = await chatbot.getAiReadable((req as any).session.username);


if(!text){

	text="no message yet..."

}


const child = spawn(`echo '
             Following is the users prompt:

	     ${text}' | ollama run deepseek-r1:8b`,{
     
     shell: true
     
     })
	
	const test = new Writable({
	
		write(data: string,callback: any){
		
		console.log(data);
		
		}
	


	})

child.stdout.on("data",(chunk)=>{
 chatbot.addChunk((req as any).session.username,chunk.toString());
console.log(chunk.toString());
})


res.end();	
	
	}



