
import {Request,Response} from "express";
import profiles from "../database/profile";

export const handler = async function(req: Request, res: Response){

	if(req.body.value && req.body.key){
	
	profiles.alterProfile((req as any).session.username, req.body.key, req.body.value)
	res.redirect("/auth/social");

	}else{
	
	res.end("NO INPUT")
	
	}


}
