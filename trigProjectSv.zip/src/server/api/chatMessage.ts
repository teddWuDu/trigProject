
import {Request,Response} from "express";
import messages from "../database/messages";

export const handler = async function(req: Request, res: Response){

	if(typeof(req.body.chatId)=="string" && typeof(req.body.message)=="string"){

await messages.addMessage((req as any).session.username,req.body.chatId,req.body.message);
res.redirect(`/auth/chat?pin=${req.body.chatId}`);
	}else{
	
		res.end("BAD REQUEST")
	
	}


}
