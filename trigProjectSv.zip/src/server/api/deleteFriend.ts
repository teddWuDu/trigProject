
import {Request,Response} from "express";
import friend from "../database/friends";

export const handler = async function(req: Request, res: Response){

await friend.deleteFriend((req as any).session.username,req.body.username);

res.redirect("/auth/friends");


}
