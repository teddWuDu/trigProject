import {Request,Response} from "express";
import {writeFile} from "node:fs";
import fs from "node:fs";
import {resolve} from "node:path";
import profile from "../database/profile";

export const handler = async function(req: Request, res: Response){

	if(req.file){

	
		const data = await profile.getProfile((req as any).session.username);
		if(!data){
		
			return
			res.end("NO DATA (INTERNAL SERVER ERROR)");	
		}
		
		
		if(data[0].filename!=="default.jpg"){
		
	        const path: string = resolve(__dirname,`../../../static/${data[0].filename}`);
		fs.unlink(path,(err)=>{
		if(err){	
			console.log("ERROR DELETING PROFILE PIC"+err.message);
		}
		})
		
				
		}

	const key: string = profile.randomKey(8);
	profile.alterProfile((req as any).session.username,"filename",key);

        const path: string = resolve(__dirname,`../../../static/${key}`);


	writeFile(path,req.file.buffer,(err)=>{
	
		if(err){
		
			res.end("<h1> FATAL SERVER ERROR</h1>")
		}
	
	
	});	
	
res.redirect("/auth/social");	
	
	}else{
	
		res.end("<h1> NO FILE </h1>")
	
	}


}
