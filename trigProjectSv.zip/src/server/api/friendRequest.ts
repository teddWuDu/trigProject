
import {Request,Response} from "express";
import inbox from "../database/inbox";

export const handler = function(req: Request, res: Response){

	if(typeof(req.body.username)=="string"){
		console.log(req.body.username);
		console.log((req as any).session.username);
	inbox.addMessage(req.body.username, (req as any).session.username,`<a href="/auth/friend?username=${(req as any).session.username}"><button>ADD ${(req as any).session.username} AS FRIEND </button></a>`)
	res.redirect(`/auth/profile?username=${req.body.username}`);
	}else{
	
		res.end("NO USERNAME")
	
	}

}
