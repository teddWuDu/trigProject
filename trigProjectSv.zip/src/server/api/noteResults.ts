
import {Request,Response} from "express";
import notes from "../database/notes";

export const handler = async function(req: Request, res: Response){

res.render("noteResults",{
	query: req.body.query,
	result: await notes.searchNotes(req.body.query)

})


}
