
const table =  [
	//First Url, then filename, lastly method
	["/api/test","./testFile.js","get"],
	["/api/render","./serverRender.js","post"],
	["/auth/chatbot","./chatbot.js","post"],
	["/login","./login.js","post"],
	["/signup","./signup.js","post"],
	["/pin","./pin.js","post"],
	["/auth/notes","./noteUpload.js","post"],
	["/auth/file/:filename","./deleteFile.js","post"],
	["/auth/noteResults","./noteResults.js","post"],
	["/auth/question","./updateProgress.js","post"],
	["/auth/clearProgress","./clearProgress.js","post"],
	["/auth/getQuestion","./getQuestion.js","post"],
	["/auth/admin","./admin.js","post"],
	["/auth/updateChat","./updateChat.js","get"],
	["/auth/clearChat","./clearChat.js","get"],
	["/auth/profilePic","./profilePic.js","post"],
	["/auth/updateProfile","./updateProfile.js","post"],
	["/auth/createChat","./createChat.js","post"],
	["/auth/getChatMessages","./getMessages.js","post"],
	["/auth/chat","./chatMessage.js","post"],
	["/auth/deleteChat","./deleteChat.js","post"],
	["/auth/findChat","./findChat.js","post"],
	["/auth/searchProfile","./searchProfile.js","post"],
	["/auth/friend","./friendRequest.js","post"],
	["/auth/deleteInbox","./deleteInbox.js","post"],
	["/auth/message","./addMessage.js","post"],
	["/auth/deleteFriend","./deleteFriend.js","post"],
]


export default table;
