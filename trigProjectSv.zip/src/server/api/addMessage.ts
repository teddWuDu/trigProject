import {Request,Response} from "express";
import inbox from "../database/inbox";

export const handler = function(req: Request, res: Response){

	inbox.addMessage(req.body.username,(req as any).session.username,req.body.message);
	res.redirect("/auth/profile?username="+req.body.username);


}
