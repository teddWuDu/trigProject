
import {Request,Response} from "express";
import progress from "../database/progress";
import pages from "../database/pages";

export const handler = function(req: Request, res: Response){

	if(req.body.section){
	pages.clearProgress((req as any).session.username,req.body.section);	
	progress.clearSection((req as any).session.username,req.body.section);
	res.redirect("/auth/homepage");
}else{
	req.pipe(process.stdout)
	res.end("NO FIELD SELECTED (INTERNAL SERVER ERROR, DATABASE RESET)");

}

}
