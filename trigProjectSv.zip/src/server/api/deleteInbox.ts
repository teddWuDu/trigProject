
import {Request,Response} from "express";
import inbox from "../database/inbox";

export const handler = async function(req: Request, res: Response){

	await inbox.clearMessages((req as any).session.username);
res.redirect("/auth/inbox");

}
