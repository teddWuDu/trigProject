
import cluster from "node:cluster"

if(cluster.isPrimary){
console.log(`MAIN PROCESS ID IS: ${process.pid}`);
cluster.fork();

}else{

import ("./server.js");


}

let counter = 0;

setInterval(function(){

	if(counter>5){
	
	throw new Error("REBOOT LOOP MAX COOLDOWN REACHED");
	
	}

	counter=0;

},3000)



cluster.on("exit",(worker: any)=>{
counter++
console.log(`SERVER CRASHED(${worker.id}), REDEPLOYING`)
	cluster.fork();
//REDEPLOY;

})
