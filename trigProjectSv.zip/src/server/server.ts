
import express from "express";
import registerApi from "./api";
import registerPages from "./pages";
import registerMiddleware from "./middleware";
import session from "express-session"; 


const app = express();
app.set("view engine","ejs");
app.set("views","views");

app.use(express.static("static"));
app.use(express.static("dist/client"));
app.use(express.json());
app.use(express.urlencoded());
app.use(session({

	secret: "182182JIdu"

}))

// Built in Middleware
registerMiddleware(app);
//CUSTOM middleware
registerApi(app);

registerPages(app);



app.listen(3000,()=>{


	console.log("SERVER HAS STARTED ON PORT 3000")

})






