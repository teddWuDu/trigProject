
import {Request,Response} from "express";

export const handler = function(req: Request, res: Response, next: any){

if((req?.session as any)?.username){
	next();

}else{


	res.redirect("/login");

}


}
