
import {Request,Response} from "express";
import {createReadStream} from "node:fs";
import {resolve} from "node:path";

export const handler = function(req: Request, res: Response, next: any){
	if(req.method==="GET"){
	if(typeof(req.params.filename)=="string"){

const path = resolve(__dirname,"../../../static/files",req.params.filename);

let stream = createReadStream(path)
stream.pipe(res);
stream.on("error",(err: any)=>{
if(err.message.replace("ENOENT: no such file or directory","")!==err.message){	
	
	next();
}else{

throw err

}
})

		
	}else{
	
		res.end("<h1> YOU DIDNT ENTER A FILENAME YOU BOZO</h1>");
	
	}
	}else{
	
	next();
	
	}
}
