import {Request,Response} from "express";

let ipArray: any = [];
let banList: any = [];

setInterval(function(){

	ipArray = [];
		banList = [];

},50000)



export const handler =  function(req: Request, res: Response, next: any){

let found = false;


	for(let i=0; i<ipArray.length; i++){

		if(ipArray[i].ip==req.ip){
			if(ipArray[i].count>400){
			found = true;
				banList.push(req.ip);
				break;

			}else{
			ipArray[i].count=ipArray[i].count+1;
			found = true;
			break;
			}
			}


	}


	if(!found){
	ipArray.push({

		ip: req.ip,
		count: 0,

	})

	}




	if(banList.indexOf(req.ip)==-1){

	next();

	}else{

		res.end("<h1>403 forbidden</h1>")

	}

}
