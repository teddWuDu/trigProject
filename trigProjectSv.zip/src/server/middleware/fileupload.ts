import {Request,Response} from "express";
import multer from "multer";

const fileMiddleware = multer({

	storage: multer.memoryStorage(),


})



export const handler  = function(req: Request,res: Response,next: any){
fileMiddleware.single("file")(req,res,next);
//FILENAME IS ALWAYS FILE!!
//ALWAYS NAME <input type="file" name="file"> ALWAYS HAVE NAME ATTRIBUTE SET TI 'file'!!
}
