
import {Request,Response} from "express";

export const handler = function(req: Request, res: Response, next: any){
if((req as any).session.username){

	res.redirect("/auth/homepage");

}else{

	next();

}


}
