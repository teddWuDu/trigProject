
const table =  [
	//First Url, then filename, lastly method
	//["/","./rateLimit.js","use"],
	["/auth/notes","./fileupload.js","use"],
	["/auth/profilePic","./fileupload.js","use"],
	["/auth","./ensureLoggedIn.js","use"],
	["/login","./ensureNotLoggedIn.js","use"],
	["/signup","./ensureNotLoggedIn.js","use"],
        ["/pin","./ensureNotLoggedIn.js","use"],
	["/auth/file/:filename","./serveFiles.js","use"],
]


export default table;
