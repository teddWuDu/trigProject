
import {file} from "./file";
import {Notes} from "./interface/table";
import {Notes as Note} from "./interface/repository";
import {Filename} from "./interface/table";
import {filter} from "./searchEngines";
import {NotesAndFilename} from "./interface/table";

class notes extends file implements Note {



async saveNote(filename: string,username: string, isPublic: string | boolean){

let pin: string | boolean = await this.saveFile(filename);
	
if(!pin){

	return false;

}


this.execute("INSERT INTO notes(username,pin,public) VALUES($username,$pin,$public)",{
	
		$username: username,
		$pin: pin,
		$public: isPublic
	})

return pin

}

async deleteNote(pin: string){

this.deleteFile(pin);
this.execute("DELETE FROM notes WHERE pin=$pin",{

	$pin: pin

})


}


async getPersonalNotes(username: string){

const result: Filename[] = [];

	const data: Notes[] = await this.execute("SELECT * FROM notes WHERE username=$username",{
	
		$username: username
	
	})

	for(let i=0; i<data.length; i++){

		let filename: string | boolean = await this.getFilename(data[i].pin);
		
		if(typeof(filename)=="string"){
	result.push({
		id: i,
		...data[i],
		filename, 
	});	
		}else{
	
                console.log(filename);
	
		return false
		
		}
	
	}

	return result;
	

}

async searchNotes(query: string){


	const data: NotesAndFilename[] = await this.execute("SELECT * FROM notes JOIN filename ON notes.pin=filename.pin WHERE public='true'",{});
	const ret = [];
		
	for(let element of data){
	
		if(filter(element.filename,query)){
		
			ret.push(element);
		
		}
	
	
	}

	return ret;

}

async changePermission(username: string, fileId: string){

	const data: Notes[] = await this.execute('SELECT * FROM notes WHERE username=$username && pin=$pin',{
	
		$username: username,
		$pin: fileId,
	
	})

	if(this.isEmpty(data)){
	
	return "PERMISSION DENIED"
	
	}
	let pub: string = "";
	if(data[0].public==="true"){
	
	pub="false"
	
	}else{
	
	pub="true"
	
	}

	this.execute(`UPDATE notes SET public=$public WHERE pin=$pin`,{
	
		$pin: data[0].pin,
		$public: pub
	
	
	})





}




}


let repo = new notes("notes");

export default repo;



