
import scaffold from "./scaffold";
import {Pages as PagesTable} from "./interface/table";
import {Pages} from "./interface/repository";
import signup from "./signup";

class pages extends scaffold implements Pages {


async savePage(username: string, section: string, page: number){
	
	if(typeof(page)!=='number'){
		return false
	
	}else if(page!==page){
		return false
	}


	const data: PagesTable[] = await this.execute('SELECT * FROM pages WHERE username=$username',{
	
		$username: username
	
	})

	
	if(section==="trigDefinition" || section==="trigFormulas" || section==="trigTransformation" || section==="complexTrig"){

	
        if(page>=4){

                return false;

        }

		this.execute(`UPDATE pages SET ${section}=$number WHERE username=$username`,{
	
		$username: username,
		$number: page
	
	})
	}else{
	
		return false
	
	}


}


async getPage(username: string, section: string){

        const data: PagesTable[] = await this.execute('SELECT * FROM pages WHERE username=$username',{

                $username: username

        })
	
	if(section==="trigDefinition" || section==="trigFormulas" || section==="trigTransformation" || section==="complexTrig"){
        
		return data[0][section]
	
	}else{

                return false

        }



}



async clearProgress(username: string, section: string){

if(section==="trigDefinition" || section==="trigFormulas" || section==="trigTransformation" || section==="complexTrig"){

	this.execute(`UPDATE pages SET ${section}=0 WHERE username=$username`,{
	
	$username: username
	
	})



        }else{

                return false

        }	



}

async initiate(username: string){

this.execute('INSERT INTO pages(username,trigDefinition,trigFormulas,trigTransformation,complexTrig) VALUES($username,0,0,0,0)',{
	     
	     $username: username
	     
	     })

}



}

const repo = new pages("pages");

export default repo;



