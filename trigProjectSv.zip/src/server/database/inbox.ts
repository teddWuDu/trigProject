import scaffold from "./scaffold";
import {Inbox} from "./interface/repository";
import {Inbox as InboxTable} from "./interface/table";

class inbox extends scaffold implements Inbox {

    async getMessages(username: string){

        const data: InboxTable[] = await this.execute('SELECT * FROM inbox WHERE recieve = $recieve',{

            $recieve: username

        } );

        return data;


    }

    async clearMessages(username: string){

        this.execute(`DELETE FROM inbox WHERE recieve = $username`,{

            $username: username,
        })

    }


    async addMessage(recieve: string, send: string, message: string): Promise<void> {
        this.execute('INSERT INTO inbox(recieve,send,message) VALUES($recieve,$send,$message)',{
            $recieve: recieve,
            $send: send,
            $message: message,

        })

    }


}

const repo = new inbox("inbox");

export default repo



