
import scaffold from "./scaffold";
import {Progress} from "./interface/repository";
import {Progress as ProgressTable} from "./interface/table";

class progress extends scaffold implements Progress {

initiate(username: string){

const query = "INSERT INTO progress(username,trigDefinitionQuestions,trigDefinitionCorrect, trigFormulasQuestions, trigFormulasCorrect,trigTransformationQuestions,trigTransformationCorrect,complexTrigQuestions, complexTrigCorrect) VALUES($username,0,0,0,0,0,0,0,0)";

this.execute(query,{

	$username: username

})


}

async questionCorrect(username: string, section: string){

	const data: ProgressTable[] = await this.execute('SELECT * FROM progress WHERE username=$username',{
	
	$username: username
	
	})
	
	if(this.isEmpty(data)){
	
	return
	
	}


	if(section=="trigDefinition" || section=="trigFormulas" || section=="trigTransformation" || section=="complexTrig"){
		this.execute(`UPDATE progress SET ${section}Questions=$number WHERE username=$username`,{
		
			$username: username,
			$number: data[0][`${section}Questions`]+1,
		
		})
		
		         this.execute(`UPDATE progress SET ${section}Correct=$number WHERE username=$username`,{

                        $username: username,
                        $number: data[0][`${section}Correct`]+1,
	
                })


	}
}
async questionWrong(username: string, section: string){



        const data: ProgressTable[] = await this.execute('SELECT * FROM progress WHERE username=$username',{

        $username: username

        })


        if(this.isEmpty(data)){

        return

        }

	
        if(section=="trigDefinition" || section=="trigFormulas" || section=="trigTransformation" || section=="complexTrig"){





                this.execute(`UPDATE progress SET ${section}Questions=$number WHERE username=$username`,{

                        $username: username,
                        $number: data[0][`${section}Questions`]+1,

                })



        }



}


getProgressInfo(username: string){

return this.execute("SELECT * FROM progress WHERE username=$username",{

	$username: username

})

}

clearSection(username: string, section: string){

this.execute(`UPDATE progress SET ${section}Questions=0 WHERE username=$username`,{

$username: username,
$section: section

})

this.execute(`UPDATE progress SET ${section}Correct=0 WHERE username=$username`,{


$username: username,
$section: section


})


}

}

const repo = new progress("progress");

export default repo;
