
import scaffold from "./scaffold";
import {Chatroom} from "./interface/repository";
import {Chatroom as ChatroomTable} from "./interface/table";
import { filter } from "./searchEngines";

class chatroom extends scaffold implements Chatroom {

	async searchChats(query: string){
	
		let result: ChatroomTable[] = [];
	const data: ChatroomTable[] = await this.execute('SELECT * FROM chatroom',{});	
	
	data.forEach((element)=>{
	
		if(filter(query,element.chatname)){
		
		result.push(element)
		
		}
	
	
	})

	if(this.isEmpty(result)){
	
		return false
	
	}

	return result
	
	
	}

	async deleteChatroom(chatId: string, username: string){
	
		const data: ChatroomTable[] = await this.execute('SELECT * FROM chatroom WHERE creator=$username && chatId=$chatId',{
		
			$username: username,
			$chatId: chatId
		
		})

		if(this.isEmpty(data)){
		
			return false
		
		}

		this.execute('DELETE FROM chatroom WHERE chatId=$chatId',{
		
			$chatId: chatId
		
		});
		this.execute('DELETE FROM messages WHERE chatId=$chatId',{
		
			$chatId: chatId
		
		})
	
	
	}

	async createChatroom(username: string, chatName: string){
	
		const key: string = this.randomKey(8);
		this.execute('INSERT INTO chatroom(chatname,chatId,creator) VALUES ($chatname,$chatId,$creator)',{
		
		$chatname: chatName,
		$chatId: key,
		$creator: username,
		
		
		})

		return key
		
	
	}



	async getChatInfo(chatId: string | undefined){

	if(typeof(chatId)!=="string"){
	
		return false
	}


	const data: ChatroomTable[] = await this.execute('SELECT * FROM chatroom WHERE chatId=$chatId',{
	
	
		$chatId: chatId
	
	})
	
	if(this.isEmpty(data)){
	
		return false
	
	}else{
	
	
		return data
	
	}
	
	
	
	}
}

const repo = new chatroom("chatroom");

export default repo;
