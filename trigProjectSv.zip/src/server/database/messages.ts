
import scaffold from "./scaffold";
import {Messages} from "./interface/repository";
import {Messages as MessagesTable} from "./interface/table";


class messages extends scaffold implements Messages {

async getMessages(chatId: string){

	const data: MessagesTable[] = await this.execute('SELECT * FROM messages WHERE chatId=$chatId',{
	
	
		$chatId: chatId
	
	
	})

return data;

}

async addMessage(username: string, chatId: string, message: string){

this.execute('INSERT INTO messages(username,message,chatId) VALUES ($username,$message,$chatId)',{

	$username: username,
	$message: message,
	$chatId: chatId,


})


}


}

const repo = new messages("messages");

export default repo;
