
import scaffold from "./scaffold";
import {MultipleChoice as MultipleChoiceTable} from "./interface/table";
import {MultipleChoice} from "./interface/repository";

class multipleChoice extends scaffold implements MultipleChoice {
	getAll(){
	
		return this.execute(`SELECT * FROM multipleChoice`,{});	
	
	}


	async getDescription(questionId: number){
	
		const data: MultipleChoiceTable[] = await this.execute('SELECT * FROM multipleChoice WHERE id=$id',{
		
			$id: Number(questionId)
		
		})

		if(this.isEmpty(data)){
		
			return false
		
		}else{
		
		return data[0].description
		
		}
	
	
	
	}


	async verify(questionId: number, choice: number){
	
		if(choice===1 || choice===2 || choice===3 || choice===4){
		
		let check: MultipleChoiceTable[]  = await this.execute('SELECT * FROM multipleChoice WHERE id=$id',{
		
			$id: questionId
		
		})

		if(this.isEmpty(check)){
		
			return false
		
		}else{
		
		if(check[0].solution===choice){
		
		return true;
		
		}else{
		
			return false;
		
		}
		
		
		
		}
		
		
		}else{
		
		return false
		
		}

	
	}

	async getRandomQuestion(catagory: string){
	
	const questions: MultipleChoiceTable[] = await this.execute('SELECT * FROM multipleChoice WHERE catagory=$catagory',{
	
	$catagory: catagory
	
	})

	if(this.isEmpty(questions)){
	
	return false	
	
	}else{

	console.log(questions);
	const key = Math.floor(Math.random()*questions.length);
	return questions[key];



		
	}
	
	}

	async addQuestion(data: MultipleChoiceTable){
	
	console.log(data);
this.execute('INSERT INTO multipleChoice (catagory,question,solution,choice1,choice2,choice3,choice4,description) VALUES ($catagory,$question,$solution,$choice1,$choice2, $choice3, $choice4, $description)',{
		$catagory: data.catagory,
		$question: data.question,
		$solution: Number(data.solution),
		$choice1: data.choice1,
		$choice2: data.choice2,
		$choice3: data.choice3,
		$choice4: data.choice4,
		$description: data.description,
		
		
		
		})
	
	}	



}


const repo = new multipleChoice("multipleChoice");
export default repo


