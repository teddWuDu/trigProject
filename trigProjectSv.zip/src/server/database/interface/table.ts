// USE TABLE NAME WITH FIRST LETTER CAPITALIZED!!
export interface Users {

id: number,
username: string,
password: string

}

export interface Filename {

id: number,
filename: string,
pin: string

}

export interface Pending {

id: number,
username: string,
password: string,
email: string,
pin: string,
}


export interface Profiles {

id: number,
username: string,
title: string,
body: string,
filename: string

}

export interface Notes {

	username: string,
	pin: string,
	public: string,
}


export interface NotesAndFilename {


        username: string,
        pin: string,
        public: string,
	id: number,
	filename: string,
}

export interface Progress {
	
	username: string, 
	trigDefinitionQuestions: number,
	trigDefinitionCorrect: number,
	trigFormulasQuestions: number,
       	trigFormulasCorrect: number,
       	trigTransformationQuestions: number,
       	trigTransformationCorrect: number,
       	complexTrigQuestions: number,
	complexTrigCorrect: number,

}

export interface MultipleChoice {
	id: number,
	question: string,
	solution: number,
	choice1: string,
	choice2: string,
	choice3: string,
	choice4: string,
	catagory: string,

        description: string,

	// SO NUMERICAL CHOICES ONLY
		
}

export interface FreeResponse {

	id: number,
	question: string,
	solution: number,
	catagory: string,	
	description: string,

}


export interface Pages {

	username: string,
	trigDefinition: number,
	trigFormulas: number,
	trigTransformation: number,
	complexTrig: number,

}




export interface Chatbot {

id: number,
username: string,
message: string,
isAi: string,
}


export interface Friends {

id: number,
user1: string,
user2: string

}


export interface Chatroom {

	chatname: string,
	chatId: string,
	creator: string,

}



export interface Messages {

	id: number,
	username: string,
	message: string,
	chatId: string,
	file: string,
}


export interface Inbox {

	id: number,
	recieve: string,
	send: string,
	message: string,
	file: string,

}

export interface History {

	username: string,
	history: string

}






