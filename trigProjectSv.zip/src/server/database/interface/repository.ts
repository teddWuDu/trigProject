import {Filename} from "./table";
import {NotesAndFilename} from "./table";
import {Progress as ProgressTable} from "./table";
import {MultipleChoice as MultipleChoiceTable} from "./table";
import {FreeResponse as FreeResponseTable} from "./table";
import {Chatbot as ChatbotTable} from "./table";
import {Chatroom as ChatroomTable} from "./table";
import  {Messages as MessagesTable} from "./table";
import {Inbox as InboxTable} from "./table";
import {Profiles as ProfilesTable} from "./table";
import {Friends as FriendsTable} from "./table";
import {History as HistoryTable} from "./table";

// REPOSITORY INTERFACES HERE!!!
export interface Login {

        checkUser(username: string, password: string): Promise<boolean>;

}

export interface Scaffold {

        execute(query: string,params: any): Promise<any[]>;
        connection: any;
        db: string;
        prepare(q: string,param: any): string;
        isEmpty(data: any): boolean;
	randomKey(length: number): string;
}


export interface Signup {

	userExists(username: string): Promise<boolean>;
	addToPending(username: string, password: string,email: string): Promise<undefined | boolean>;
	addToUsers(username: string, password: string, email: string): Promise<undefined | boolean>;


}

export interface File {

	getFilename(pin: string): Promise<string | boolean>;
	saveFile(filename: string): Promise<boolean | string>;
	deleteFile(pin: string): Promise<boolean>;
}

export interface Notes {

	saveNote(filename: string,username: string,isPublic: string | boolean): Promise<string | boolean>;
	deleteNote(pin: string): void;
	getPersonalNotes(username: string): Promise<Filename[] | boolean>;
	searchNotes(query: string): Promise<NotesAndFilename[]>; 
	changePermission(username: string, fileId: string): void;
}


export interface Progress {
	initiate(username: string): void;
	questionCorrect(username: string,section: string): void;
	questionWrong(username: string, section: string): void;
	clearSection(username: string, section: string): void;
	getProgressInfo(username: string, section: string): Promise<ProgressTable[]>; 


}

export interface MultipleChoice {
	getDescription(questionId: number): Promise<string | boolean>
	verify(questionId: number,choice: number): Promise<boolean> | boolean;
	getRandomQuestion(catagory: string): Promise<MultipleChoiceTable | boolean>;
	addQuestion(data: MultipleChoiceTable): Promise<void | undefined>;
}


export interface FreeResponse {
	
        verify(questionId: number,choice: number): Promise<boolean> | boolean;
        getRandomQuestion(catagory: string): Promise<FreeResponseTable | boolean>;
	addQuestion(data: FreeResponseTable): Promise<void>;
	getDescription(questionId: number): Promise<string | boolean>;
}

export interface Pages {

	savePage(username: string, section: string, page: number): Promise<boolean | undefined>;
	getPage(username: string, section: string): Promise<number | boolean>;
	clearProgress(username: string, section: string): Promise<boolean | undefined>;
	initiate(username: string): Promise<void>;
}

export interface Chatbot {

	addMessage(username: string, message: string): void;
	addChunk(username: string, chunk: string): Promise<void>;
	getMessages(username: string): Promise<ChatbotTable[]>;
	deleteMessages(username: string): Promise<void>;
	getAiReadable(username: string): Promise<string | undefined>;
}


export interface Friends {

	addFriend(user1: string, user2: string): Promise<void | boolean>;
	deleteFriend(user1: string, user2: string): Promise<void>;
	getFriends(username: string): Promise<FriendsTable[]>;


}


export interface Chatroom {

	deleteChatroom(username: string, chatName: string): Promise<void | boolean>;
	createChatroom(chatId: string, username: string): Promise<string>;
	getChatInfo(chatId: string | undefined): Promise<ChatroomTable[] | boolean>;
	searchChats(searchQuery: string): Promise<ChatroomTable[] | boolean>;
	
}

export interface Messages {

	getMessages(chatId: string): Promise<MessagesTable[]>;
	addMessage(username: string, chatId: string, message: string): Promise<void>;

}

export interface Inbox {

	getMessages(username: string): Promise<InboxTable[]>;
	clearMessages(username: string): Promise<void>;
	addMessage(recieve: string, send: string, message: string): Promise<void>;
	

}

export interface Profiles {

	initiateProfile(username: string): Promise<void>;
	alterProfile(username: string, key: string, value: string): Promise<boolean | undefined>;
	getProfile(username: string): Promise<ProfilesTable[] | boolean>;	
	searchProfile(query: string): Promise<ProfilesTable[] | boolean>;
}


export interface History {
	
	initiateHistory(username: string): Promise<void>;
	addToHistory(username: string, url: string): Promise<void>;
	getHistory(username: string): Promise<string[]>;
}




// END OF REPOSITORY INTERFACES
