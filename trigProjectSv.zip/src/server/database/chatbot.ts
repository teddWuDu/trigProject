
import scaffold from "./scaffold";
import {Chatbot as ChatbotTable} from "./interface/table";
import {Chatbot} from "./interface/repository";

class chatbot extends scaffold implements Chatbot {


async deleteMessages(username: string){

	this.execute('DELETE FROM chatbot WHERE username=$username',{
	
		$username: username
	
	})
}


async getMessages(username: string){

	const data: ChatbotTable[] = await this.execute('SELECT * FROM chatbot WHERE username=$username',{
	
		$username: username
	
	})

return data

}

async getAiReadable(username: string){

	const data = await this.getMessages(username);

	if(this.isEmpty(data)){
	
		return
	
	}

	let text = "";
	for(let element of data){
	
		if(element.isAi=="true"){
		
			text = text+ ("YOU SAID: "+element.message)
		
		}else{
		
			text = text + (`USER: ${element.username} SAID: `+element.message);
		
		}
	
	
	}

return text;


}



async addMessage(username: string, message: string){


	this.execute('INSERT INTO chatbot(username, message, isAi) VALUES($username,$message,"false")',{
	
		$username: username,
		$message: message,
	
	
	})
}




async addChunk(username: string, chunk: string){

const messages: ChatbotTable[] = await this.getMessages(username);


let latestAi = messages.pop();


if(latestAi?.isAi!=="true"){

await this.execute('INSERT INTO chatbot(username, message, isAi) VALUES($username,$message,"true")',{

	$username: username,
	$message: chunk.toString(),

})


}else{

	const newMessage = latestAi.message+chunk.toString();

await this.execute('UPDATE chatbot SET message=$message WHERE id=$id',{

        $message: newMessage,
	$id: latestAi.id

})

}
}


}

const repo = new chatbot("chatbot");

export default repo;













