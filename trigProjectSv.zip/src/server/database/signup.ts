


import scaffold from "./scaffold";
import {Signup} from "./interface/repository";
import {Pending,Users} from "./interface/table";
import progress from "./progress";
import pages from "./pages";
import profiles from "./profile";
import history from "./history";

class signup extends scaffold implements Signup {

async userExists(username: string){

	let data: Users[] = await this.execute('SELECT * FROM users WHERE username=$username',{
	
		$username: username
	
	})
	
	if(this.isEmpty(data)){

         let pending: Pending[] = await this.execute('SELECT * FROM pending WHERE username=$username',{

                $username: username

        })
	
	if(this.isEmpty(pending)){

		return false

	}else{
		return true
	}
	}else{
	
		return true
	}

}

async addToPending(username: string, password: string, email: string){

const check: boolean = await this.userExists(username);


if(!check){

this.execute('INSERT INTO pending(username,email,password,pin) VALUES($username,$email,$password,$pin)',{

	$username: username,
	$password: password,
	$email: email,
	$pin: this.randomKey(8),

})


}else{

return false;

}
}
async addToUsers(pin: string){

let data: Pending[] = await this.execute('SELECT * FROM pending WHERE pin=$pin',{

	$pin: pin
})


if(!this.isEmpty(data)){
	
	this.execute('DELETE FROM pending WHERE pin=$pin',{
	
	$pin: pin
	
	})

	pages.initiate(data[0].username);
        progress.initiate(data[0].username);
	profiles.initiateProfile(data[0].username);
        history.initiateHistory(data[0].username);
	this.execute('INSERT INTO users(username,password) VALUES($username,$password)',{
	
		$username: data[0].username,
		$password: data[0].password
	
	
	})




}else{

return false;

}



}




}







const repository = new signup("signup");


export default repository;



