
import database from "mysql2";
import {Scaffold} from "./interface/repository";




export default class scaffold implements Scaffold {
connection: any;
db: string;
constructor(db: string){

	this.connection = database.createConnection({
	
		database: "trigApp",
		user: "guest",
		password: "182182",
		
	
	})
	this.db = db;
}


prepare(query: string,params: any){

   let keys =  Object.keys(params);

    for(let element of keys){

        if(element[0]!=="$"){

            throw new Error("PREPARED STATEMENT DOES NOT START WITH $")

        }else{
       		if(typeof(params[element])=="string"){     
		
			query =  query.replaceAll(element.toString(),"\'"+params[element].replaceAll("'",'"').replaceAll('\\',"")+"\'");
		
		}else{
	

                        query =  query.replaceAll(element.toString(),params[element]);

		
		}
        }

    }

return query;


}


execute(query: string,params: any): Promise<any[]>{
console.log(this.prepare(query,params));
	return new Promise((res,rej)=>{
this.connection.execute(this.prepare(query,params),(err: any,data: any)=>{

	if(err){
	console.log("QUERY WITH ERROR IS: "+ this.prepare(query,params));	
		throw new Error("FATAL DATABASE ERROR"+err)
	
	
	}else{
	
		res((data as any[]));
	
	}
		

})
	})


}

isEmpty(data: any){

	if(data.length==0){
	
		return true
	
	}else{
	
		return false
	
	}


}

randomKey(length: number){
	let key: string = "";
	let characters = [1,2,3,4,5,6,7,8,9,0,"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"];

	for(let i=0; i<length; i++){
	
		key = key + characters[Math.floor(Math.random()*(characters.length-1))];
	
	
	}

	return key;



}



}

