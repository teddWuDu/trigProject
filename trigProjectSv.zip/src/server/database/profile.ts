
import scaffold from "./scaffold";
import {Profiles} from "./interface/repository";
import {Profiles as ProfilesTable} from "./interface/table";
import file from "./file";
import {filter} from "./searchEngines";

class profiles extends scaffold implements Profiles {

	async initiateProfile(username: string){
	
	await this.execute("INSERT INTO profiles(username,title,body,filename) VALUE($username,$title,$body,$filename)",{
	
		$username: username,
		$title: "SOME TITLE TEXT...",
		$body: "REPLACE ME...",
		$filename: "default.jpg"
	
	})
	
	}

	async alterProfile(username: string, key: string, value: string){
	
	if(key=="title" || key=="body" || key=="filename"){
	
		await this.execute(`UPDATE profiles SET ${key}=$value WHERE username=$username`,{
		
			$value: value,
			$username: username
		
		})
	
	}else{
	
	return false;
	
	}
	}

	async getProfile(username: string){
	
	const data: ProfilesTable[] = await this.execute('SELECT * FROM profiles WHERE username=$username',{
	
		$username: username
	
	})

	if(this.isEmpty(data)){
	
		return false
	
	}

	return data
	
	
	}

	async searchProfile(query: string){
	
	const data: ProfilesTable[] = await this.execute("SELECT * FROM profiles",{});
	let result: ProfilesTable[] = [];
	data.forEach((element)=>{
		if(filter(element.username,query) || filter(element.title,query)){
		
		result.push(element);
		
		}
	
		})

		if(this.isEmpty(result)){
		
			return false
		
		}

		return result	
	
	
	}


}

const repo = new profiles("profiles");

export default repo;
