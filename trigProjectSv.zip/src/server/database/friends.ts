
import scaffold from "./scaffold";
import {Friends} from "./interface/repository";
import {Friends as FriendsTable} from "./interface/table";

class friends extends scaffold implements Friends {

async addFriend(user1: string, user2: string){
	
	const data1: FriendsTable[] = await this.execute('SELECT * FROM friends WHERE user1=$user1 && user2=$user2',{
	
		$user1: user1,
		$user2: user2
	
	
	})

	
        const data2: FriendsTable[] = await this.execute('SELECT * FROM friends WHERE user1=$user2 && user2=$user1',{

                $user1: user1,
                $user2: user2


        })

	if(this.isEmpty(data1) && this.isEmpty(data2)){


	this.execute('INSERT INTO friends(user1,user2) VALUES ($user1,$user2)',{
	
		$user1: user1,
		$user2: user2
	
	})
	}else{
	
	return false
	
	}
}


async deleteFriend(user1: string, user2: string){

        this.execute('DELETE FROM friends WHERE user1=$user1 && user2=$user2',{

                $user1: user1,
                $user2: user2

        })

	
        this.execute('DELETE FROM friends WHERE user1=$user1 && user2=$user2',{

                $user1: user2,
                $user2: user1

        })



}

async getFriends(username: string){
	
	const data: FriendsTable[] = await this.execute('SELECT * FROM friends WHERE user1=$username || user2=$username',{
	
		$username: username
	
	})

	return data


}



}

const repo = new friends("friends");
export default repo;
