import scaffold from "./scaffold";
import {Login} from "./interface/repository";
import {Users} from "./interface/table";



class login extends scaffold implements Login {

async checkUser(username: string, password: string){

	let data: Users[] = await this.execute("SELECT * FROM users WHERE username=$username && password=$password",{
	
		$username: username,
		$password: password
	
	})

	if(this.isEmpty(data)){
	
	return false;
	}else{
	
		return true;
	
	}



}



}


const repo = new login("users");
export default repo;

