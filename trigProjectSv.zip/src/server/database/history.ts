
import {History} from "./interface/repository";
import {History as HistoryTable} from "./interface/table";
import scaffold from "./scaffold";

class history extends scaffold implements History {


	async initiateHistory(username: string){
	
	
	this.execute("INSERT INTO history(username,history) VALUES ($username,$history)",{
	
		$username: username,
		$history: JSON.stringify([])
	
	})
	
	}

	
	async getHistory(username: string){
	
	const data: HistoryTable[] = await this.execute("SELECT * FROM history WHERE username=$username",{
	
		$username: username
	
	})

	return JSON.parse(data[0].history);
		
	}

	
	async addToHistory(username: string, url: string){
		
	const data: string[] = await this.getHistory(username);
	data.push(url);
	
	if(data.length>10){
	
	data.splice(0,1);
	
	}	

	this.execute('UPDATE history SET history=$history WHERE username=$username',{
	
		$username: username,
		$history: JSON.stringify(data)
	
	})	
	
	}
}

const repo = new history("history");

export default repo

