
import scaffold from "./scaffold";
import {FreeResponse as FreeResponseTable} from "./interface/table";
import {FreeResponse} from "./interface/repository";

class freeResponse extends scaffold implements FreeResponse {

	
	getAll(){
	
		return this.execute('SELECT * FROM freeResponse',{});
	
	}


	async addQuestion(data: FreeResponseTable){
	
	this.execute('INSERT INTO freeResponse (question,solution,catagory,description) VALUES ($question,$solution,$catagory,$description)',{
	
		$question: data.question,
		$solution: data.solution,
		$catagory: data.catagory,
		$description: data.description
	
	
	})
	
	
	
	}

async getDescription(questionId: number){

const data: FreeResponseTable[] = await this.execute('SELECT * FROM freeResponse WHERE id=$id',{

	$id: questionId

})

if(this.isEmpty(data)){

	return false

}

return data[0].description;



}





async verify(questionId: number, choice: number){

	const data: FreeResponseTable[] = await this.execute("SELECT * FROM freeResponse WHERE id=$id",{
	
		$id: questionId
	
	})

	if(this.isEmpty(data)){
	
		return false
	
	}


	if(data[0].solution==choice){
	
		return true
	
	}else{
	
		return false
	
	}


}


async getRandomQuestion(catagory: string){

	const data: FreeResponseTable[] = await this.execute(`SELECT * FROM freeResponse WHERE catagory=$catagory`,{
	
		$catagory: catagory
	
	
	})
	

	if(this.isEmpty(data)){

	
		return false
	
	}


	const key = Math.floor(Math.random()*data.length);
	return data[key];





}






}

const repo = new freeResponse("freeResponse");

export default repo;
