let filterExtra = function(string: string,query: string){
let streak = 0;
let health = 0;
    for(let i=0; i<string.length; i++){

        if(string.toLowerCase()[i]==query.toLowerCase()[i]){
            health = 1;
           streak++
            
        }else{

       health--
            i++
        }

            if(health===0){

    streak=0;
        
    }

    if(streak===query.length-1){

        return true
        
    }
    
    
        
    }

    return false;


    
}

const filterMinus = function(string: string ,query: string){
let streak = 0;
let health = 0;
    let count1 = 0;
    for(let i=0; i<string.length; i++){
        count1++;
        if(string.toLowerCase()[i]==query.toLowerCase()[count1]){
            health = 1;
           streak++
            
        }else{

       health--
            count1--
        }

            if(health===0){

    streak=0;
        
    }

    if(streak===query.length-1){

        return true
        
    }
    
    
        
    }

    return false;


    
}

export const filter = function(string: string, query: string){

	if(typeof(string)!=="string" || typeof(query)!=="string"){
	
	return false
	
	}


if(filterExtra(string,query) || filterMinus(string,query)){

        return true
        
    }
    return false

}
