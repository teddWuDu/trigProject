
import {Filename} from "./interface/table";
import {File} from "./interface/repository";
import scaffold from "./scaffold";

export class file extends scaffold implements File {

	async getFilename(pin: string){
	
	let data: Filename[] = await this.execute("SELECT * FROM filename WHERE pin=$pin",{
	
		$pin: pin
	
	}) 

	if(this.isEmpty(data)){
	
	return false
	
	}else{
	
		return data[0].filename
	
	
	}
	
	
	
	
	}

	async saveFile(filename: string){
	
	try{
	let pin = this.randomKey(8);	
	await this.execute("INSERT INTO filename(filename,pin) VALUES($filename,$pin)",{
	
		$filename: filename,
		$pin: pin
	
	})	


	return pin;
	}catch(err){

        console.log(err);
	
	return false;

	}
		
	}


	async deleteFile(pin: string){
	try{
		await this.execute('DELETE FROM filename WHERE pin=$pin',{
		
			$pin: pin

		})
		return true
	}catch(err){
	
		return false
	
	}
	}
}


const repo = new file("filename");
export default repo;


